import requests
from bs4 import BeautifulSoup

# URL of the website to scrape
url = "https://www.bbc.com/news"


response = requests.get(url)


if response.status_code == 200:

    soup = BeautifulSoup(response.content, "html.parser")

    # Find all headlines in the page
    headlines = soup.find_all("h3")

    print("Top Headlines:")
    for index, headline in enumerate(headlines[:10], start=1):
        print(f"{index}. {headline.text.strip()}")
else:
    print(f"Failed to retrieve the page. Status code: {response.status_code}")
