import random

# Word bank with hints
words_with_hints = {
    "python": "A popular programming language.",
    "hangman": "A classic word guessing game.",
    "algorithm": "A step-by-step procedure for solving a problem.",
    "developer": "A person who writes code.",
    "internet": "A global network connecting millions of devices.",
}

def display_hangman(tries):
    stages = [
        """
           -----
           |   |
           O   |
          /|\\  |
          / \\  |
               |
        --------
        """,
        """
           -----
           |   |
           O   |
          /|\\  |
          /    |
               |
        --------
        """,
        """
           -----
           |   |
           O   |
          /|\\  |
               |
               |
        --------
        """,
        """
           -----
           |   |
           O   |
          /|   |
               |
               |
        --------
        """,
        """
           -----
           |   |
           O   |
           |   |
               |
               |
        --------
        """,
        """
           -----
           |   |
           O   |
               |
               |
               |
        --------
        """,
        """
           -----
           |   |
               |
               |
               |
               |
        --------
        """,
    ]
    return stages[tries]

def hangman():
    word, hint = random.choice(list(words_with_hints.items()))
    guessed_word = ["_"] * len(word)
    guessed_letters = set()
    tries = 6

    print("Welcome to Hangman!")
    print(f"Hint: {hint}")

    while tries > 0:
        print(display_hangman(tries))
        print("Word: " + " ".join(guessed_word))
        print(f"Guessed letters: {', '.join(sorted(guessed_letters))}")
        guess = input("Enter a letter: ").lower()

        if len(guess) != 1 or not guess.isalpha():
            print("Please enter a single valid letter.")
            continue

        if guess in guessed_letters:
            print("You already guessed that letter.")
            continue

        guessed_letters.add(guess)

        if guess in word:
            print(f"Good job! '{guess}' is in the word.")
            for i, letter in enumerate(word):
                if letter == guess:
                    guessed_word[i] = guess
        else:
            print(f"Sorry, '{guess}' is not in the word.")
            tries -= 1

        if "_" not in guessed_word:
            print("\nCongratulations! You guessed the word!")
            print(f"The word was: {word}")
            break
    else:
        print(display_hangman(tries))
        print("You ran out of tries. Better luck next time!")
        print(f"The word was: {word}")


hangman()
