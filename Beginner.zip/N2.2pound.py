radius=84
pi=3.14
water_square_meter=1.4

#arear of pound
area_of_pond=pi*(radius**2)

#calculating the total amount of water in pound
total_water=area_of_pond*water_square_meter

print('Total amount of water in pound(in liters)',int(total_water))
