def format_example(number, representation):
    # Format the number based on the representation
    result = format(number, representation)
    return result

# Call the function with 145 and 'o'
formatted_result = format_example(145, 'o')
print("Formatted Result:", formatted_result)
