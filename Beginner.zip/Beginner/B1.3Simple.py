#creating different variables for principle amount,rate of interest and time
principle_amount=2599
rate_of_interest=4 #(in %)
time=3 #(time in years)

#calculating simple interest
simple_interest=(principle_amount*rate_of_interest*time)/100

print("Simple interest for 3 years is:",simple_interest)