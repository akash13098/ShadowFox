import random

# Number of times to roll the die
num_rolls = 20

# Variables to store the counts
count_6 = 0
count_1 = 0
count_double_6 = 0


previous_roll = None
for _ in range(num_rolls):
    roll = random.randint(1, 6)  # Roll a six-sided die

    # Count how many times we rolled a 6 or a 1
    if roll == 6:
        count_6 += 1
    if roll == 1:
        count_1 += 1

    # Count how many times we rolled two 6s in a row
    if previous_roll == 6 and roll == 6:
        count_double_6 += 1

    previous_roll = roll


print("Number of times you rolled a 6:", count_6)
print("Number of times you rolled a 1:", count_1)
print("Number of times you rolled two 6s in a row:", count_double_6)
