distance=490 #in meters
time=7 #in minutes

#converting minutes to second
time_in_sec=7*60

#calculating speed in meters per second
speed=distance/time_in_sec

print("speed is",int(speed),"meter per second,")