#variable named pi
pi=22/7

#Displaying the type of varaible(pi)
print(type(pi))