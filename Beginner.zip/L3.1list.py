justice_league = ["Superman","Batman","Wonder Woman","Flash","Aquaman","Green Lantern"]

# the number of members in the Justice League.
print("1.The number of members in the Justice League are:",len(justice_league))

#  Adding Batgirl and Nightwing to the list
justice_league.extend(["Batgirl", "Nightwing"])
print(" \nAfter adding Batgirl and Nightwing:", justice_league)

# Moving Wonder Woman to the beginning of the list
justice_league.remove("Wonder Woman")
justice_league.insert(0, "Wonder Woman")
print("2. Wonder Woman is now the leader:", justice_league)

#  Moving Green Lantern between Aquaman and Flash
justice_league.remove("Green Lantern")
flash_index = justice_league.index("Flash")
justice_league.insert(flash_index, "Green Lantern")
print("3.After separating Aquaman and Flash:", justice_league)

#  Replacing the existing list with new members
justice_league = ["Cyborg", "Shazam", "Hawkgirl", "Martian Manhunter", "Green Arrow"]
print("4.Superman assembled a new team:", justice_league)

# Sort the Justice League alphabetically
justice_league.sort()
print("5.After sorting alphabetically:", justice_league)
print("6.BONUS: The new leader is:", justice_league[0])