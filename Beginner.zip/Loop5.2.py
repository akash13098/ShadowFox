# Total number of jumping jacks
total_jumping_jacks = 100
completed_jumping_jacks = 0


while completed_jumping_jacks < total_jumping_jacks:
    # Perform 10 jumping jacks at a time
    completed_jumping_jacks += 10
    print(f"You've completed {completed_jumping_jacks} jumping jacks.")


    tired = input("Are you tired? (yes/y/no/n): ").lower()

    if tired == "yes" or tired == "y":
        # Ask if the user wants to skip remaining sets
        skip = input("Do you want to skip the remaining sets? (yes/y/no/n): ").lower()

        if skip == "yes" or skip == "y":

            print(f"You completed a total of {completed_jumping_jacks} jumping jacks.")
            break
    elif tired == "no" or tired == "n":
        # Display how many jumping jacks are remaining
        remaining_jumping_jacks = total_jumping_jacks - completed_jumping_jacks
        print(f"{remaining_jumping_jacks} jumping jacks remaining.")

    # Check if the user completed all jumping jacks
    if completed_jumping_jacks == total_jumping_jacks:
        print("Congratulations! You completed the workout.")
        break
